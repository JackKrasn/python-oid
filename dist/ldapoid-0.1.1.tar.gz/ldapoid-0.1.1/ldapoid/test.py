import ld


SERVER='bsoid1:3060'
DN='cn=orcladmin, cn=Users, dc=ftc, dc=ru'
PASS='oidpassword123'
dn_domain='dc=ftc, dc=ru'

conn = ld.connection(SERVER, DN, PASS)
# conn = ld.ldap.initialize('ldap://' + SERVER)
# conn.simple_bind_s(DN, PASS)


ld.create_dbalias(conn, dn_domain=dn_domain, dbalias='182_PY_TEST2', host='hamilton.ftc.ru', lisport=1548, sn='B0S3174RO1S44'.lower())