Description
===================

The package is designed to work with Oracle Internet Directory.
The package allows:

  - create dbalias
  - delete dbalias

