# -*- coding: utf-8 -*-
from .ld import *

__version__ = '0.1.0'  # https://semver.org/lang/ru/
__author__ = 'Evgeniy Krasnukhin'
__author_email__ = 'e.krasnukhin@cft.ru'